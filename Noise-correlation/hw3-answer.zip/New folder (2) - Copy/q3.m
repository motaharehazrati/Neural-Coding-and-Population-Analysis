clear all; close all; clc;
binWidth = 20;
nMonkey = 3;
t = 0:binWidth:1000-binWidth;
gratsNum = 12;
filenames{1} = './spikes_gratings/data_monkey1_gratings.mat';
filenames{2} = './spikes_g ratings/data_monkey2_gratings.mat';
filenames{3} = './spikes_gratings/data_monkey3_gratings.mat';

monkeys = {'S_monkey1.mat','S_monkey2.mat','S_monkey3.mat'};
dataS = {'data_monkey1_gratings.mat','data_monkey2_gratings.mat','data_monkey3_gratings.mat'};
SNR_th = 2;
r1 = {};
r2 = {};
r3 = {};
r4 = {};
for imonkey = 1:nMonkey
    rtmp1 = [0;0];
    rtmp2 = [0;0];
    rtmp3 = [0;0];
    rtmp4 = [0;0];

    load(dataS{imonkey});
    load(monkeys{imonkey});

    map = data.MAP;
    keepNeurons = data.SNR > SNR_threshold;
    goodNeurons = find(keepNeurons);

    ch = data.CHANNELS;
    ch(:,2) = [];

    n = size( goodNeurons,1);
    tunMat = zeros(12,length(n));
    for i = 1:length(find(n))
        tuningCurve = zeros(1,12);
        for igrat = 1:12
            tmp = S(igrat).mean_FRs;
            tuningCurve(igrat) = mean(tmp(i,:));
        end
        tunMat(:,i) = tuningCurve;
    end
    corrMat = corr(tunMat);

    tic
    for i = 1:length(find(n))-1
        for j = i+1:length(find(n))
            rSig = corrMat(i,j);
            if (rSig > 0.5)
                % Finding r_sc
                tunCur01 = tunMat(:,i);
                tunCur02 = tunMat(:,j);
                pref01 = find(tunCur01 == max(tunCur01));
                pref02 = find(tunCur02 == max(tunCur02));
                count01 = zeros(200,1);
                count02 = zeros(200,2);
                for trl = 1:200
                    tmp01 = S(pref01).trial(trl).counts;
                    tmp02 = S(pref02).trial(trl).counts;
                    count01(trl) = sum(tmp01(i,:));
                    count02(trl) = sum(tmp02(j,:));
                end
                % ====================================================!!!!!!!!!!!!!!!!!
                zsc = zscore([count01, count02]);
                rsc = corr(zsc);
                rsc = rsc(2);

                % finding distance
                unit01 = ch(i);
                unit02 = ch(j);
                if (unit01 ~= unit02)
                    [row01, col01] = find(map == unit01);
                    [row02, col02] = find(map == unit02);
                    dis = sqrt((row02-row01)^2 + (col02-col01)^2) * 0.25;
                    rtmp1 = [rtmp1, [rsc;dis]];
                end
            end
            
            if (rSig>0 && rSig<0.5)
                % Finding r_sc
                tunCur01 = tunMat(:,i);
                tunCur02 = tunMat(:,j);
                pref01 = find(tunCur01 == max(tunCur01));
                pref02 = find(tunCur02 == max(tunCur02));
                count01 = zeros(200,1);
                count02 = zeros(200,2);
                for trl = 1:200
                    tmp01 = S(pref01).trial(trl).counts;
                    tmp02 = S(pref02).trial(trl).counts;
                    count01(trl) = sum(tmp01(i,:));
                    count02(trl) = sum(tmp02(j,:));
                end
                % ====================================================!!!!!!!!!!!!!!!!!
                zsc = zscore([count01, count02]);
                rsc = corr(zsc);
                rsc = rsc(2);

                % finding distance
                unit01 = ch(i);
                unit02 = ch(j);
                if (unit01 ~= unit02)
                    [row01, col01] = find(map == unit01);
                    [row02, col02] = find(map == unit02);
                    dis = sqrt((row02-row01)^2 + (col02-col01)^2) * 0.25;
                    rtmp2 = [rtmp2, [rsc;dis]];
                end
            end
            
            if (rSig>-0.5 && rSig<0)
                % Finding r_sc
                tunCur01 = tunMat(:,i);
                tunCur02 = tunMat(:,j);
                pref01 = find(tunCur01 == max(tunCur01));
                pref02 = find(tunCur02 == max(tunCur02));
                count01 = zeros(200,1);
                count02 = zeros(200,2);
                for trl = 1:200
                    tmp01 = S(pref01).trial(trl).counts;
                    tmp02 = S(pref02).trial(trl).counts;
                    count01(trl) = sum(tmp01(i,:));
                    count02(trl) = sum(tmp02(j,:));
                end
                % ====================================================!!!!!!!!!!!!!!!!!
                zsc = zscore([count01, count02]);
                rsc = corr(zsc);
                rsc = rsc(2);
                
                % finding distance
                unit01 = ch(i);
                unit02 = ch(j);
                if (unit01 ~= unit02)
                    [row01, col01] = find(map == unit01);
                    [row02, col02] = find(map == unit02);
                    dis = sqrt((row02-row01)^2 + (col02-col01)^2) * 0.25;
                    rtmp3 = [rtmp3, [rsc;dis]];
                end
            end
            
            if (rSig<-0.5)
                % Finding r_sc
                tunCur01 = tunMat(:,i);
                tunCur02 = tunMat(:,j);
                pref01 = find(tunCur01 == max(tunCur01));
                pref02 = find(tunCur02 == max(tunCur02));
                count01 = zeros(200,1);
                count02 = zeros(200,2);
                for trl = 1:200
                    tmp01 = S(pref01).trial(trl).counts;
                    tmp02 = S(pref02).trial(trl).counts;
                    count01(trl) = sum(tmp01(i,:));
                    count02(trl) = sum(tmp02(j,:));
                end
                % ====================================================!!!!!!!!!!!!!!!!!
                zsc = zscore([count01, count02]);
                rsc = corr(zsc);
                rsc = rsc(2);

                % finding distance
                unit01 = ch(i);
                unit02 = ch(j);
                if (unit01 ~= unit02)
                    [row01, col01] = find(map == unit01);
                    [row02, col02] = find(map == unit02);
                    dis = sqrt((row02-row01)^2 + (col02-col01)^2) * 0.25;
                    rtmp4 = [rtmp4, [rsc;dis]];
                end
            end
        end
    end
    rtmp1(:,1) = [];
    rtmp2(:,1) = [];
    rtmp3(:,1) = [];
    rtmp4(:,1) = [];
    r1{imonkey} = rtmp1;
    r2{imonkey} = rtmp2;
    r3{imonkey} = rtmp3;
    r4{imonkey} = rtmp4;
    toc
end 

colors = {[.5 .5 .5],[1 .0 .0],[.0 .0 1],[.0 1 .0]};
thickness = [5,4,3,1.5];
leg = {'rSig > 0.5', '0 < rSig < 0.5', '-0.5 < rSig < 0', 'rSig < -0.5'};
for imonkey = 1:3
    rStruct = {r1{imonkey},r2{imonkey},r3{imonkey},r4{imonkey}};
    figure;
    for j = 1:4
        r = rStruct{j};
        x = unique(r(2,:));
        meanMat = [];
        stdMat = [];
        for i = 1:length(x)
            inds = find(r(2,:) == x(i));
            meanMat(i) = mean(r(1,inds));
            stdMat(i) = std(r(1,inds));
        end
        stdMat = stdMat/sqrt(200);
%         scatter(r(2,:),r(1,:));
        errorbar(x(1:3:end),meanMat(1:3:end),stdMat(1:3:end),'k','LineWidth',1,'LineStyle','none','HandleVisibility','off')
        hold on
        plot(x,meanMat,'color',colors{j},'LineWidth',thickness(j))
%         ylim([-0.1 0.3])
        xlabel("Distance Between Electrodes(mm)")
        ylabel("Spike Count Correlation(r_{sc})")
        title(sprintf("Monkey %d",imonkey))
    end
    legend(leg{1},leg{2},leg{3},leg{4});
end

figure;
for imonkey = 1:3
    r = r1{imonkey};
    x = unique(r(2,:));
    meanMat = [];
    stdMat = [];
    for i = 1:length(x)
        inds = find(r(2,:) == x(i));
        meanMat(i) = mean(r(1,inds));
        stdMat(i) = std(r(1,inds));
    end
    stdMat = stdMat/sqrt(200);
    subplot(1,3,imonkey)
    errorbar(x,meanMat,stdMat,'k','LineWidth',1,'LineStyle','none','HandleVisibility','off')
    plot(x,meanMat,'k','LineWidth',2)
    ylim([0 0.3])
    xlabel("Distance Between Electrodes(mm)")
    ylabel("Spike Count Correlation(r_{sc})")
    title(sprintf("Monkey %d (rSig > 0.5)",imonkey))
    grid on
end