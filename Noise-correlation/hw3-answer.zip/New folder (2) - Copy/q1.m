% clear all; close all; clc;

binWidth = 20;
nMonkey = 3;
t = 0:binWidth:1000-binWidth;
gratsNum = 12;
monkeys = {'S_monkey1.mat','S_monkey2.mat','S_monkey3.mat'};
activeNeurons = zeros(nMonkey,gratsNum,3);
grat={'000', '030', '060' , '090', '120', '150', '180', '210','240', '270', '300', '330'};
for imonkey = 1:nMonkey
    load(monkeys{imonkey});

    n = size(S(1).mean_FRs,1);
    figure;
    for igrat = 1:gratsNum
        psth = S(igrat).mean_FRs;
        meanVec = mean(psth,2);
        indMax1 = find(meanVec == max(meanVec)); % First Maximum
        subplot(6,2,igrat)
        for i = 1:n
            plot(t,psth(i,:),'k','HandleVisibility','off')
            if (i == indMax1)
                h1 = plot(t,psth(i,:),'r','LineWidth',1.8,'DisplayName',sprintf('Neuron %d',indMax1));
            end
            hold on
        end
         legend([h1]);
        title("PSTH of Neurons " +  num2str(grat{igrat}))
        xlabel("t(ms)")
        ylabel("firing rate")
    end
end
figure
gratX = 0:30:330;
neurons = [4, 30, 57]; % Chosen neurons for each monkey
tuningCurve = zeros(3,12);
for imonkey = 1:nMonkey
    load(monkeys{imonkey});
    for igrat = 1:gratsNum
        psth = S(igrat).mean_FRs;
        meanVec = mean(psth,2);
        indMax1 = find(meanVec == max(meanVec));
        tuningCurve(imonkey,igrat) = mean(psth(indMax1,:));
    end
end
for i = 1:3
    subplot(1,3,i)
    plot(gratX, tuningCurve(i,:), 'k', 'LineWidth', 2)
    ylabel("mean activity")
    xlabel("preferred stimulus")
    title(sprintf("Tuning Curve of Neuron %d of Monkey %d",neurons(i),i));
    xlim([0,330])
    grid on
end