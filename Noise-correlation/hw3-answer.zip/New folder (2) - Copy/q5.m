clear all; clc; close all;

datanames = [{'spiketimesmonkey1spont'} {'spiketimesmonkey2spont'} {'spiketimesmonkey3spont'} {'spiketimesmonkey4spont'} {'spiketimesmonkey5spont'} {'spiketimesmonkey6spont'}];

SNR_th = 2;
bininseconds = 1;
spacebetweenbins = 0;

for imonkey = 1: length(datanames)
    load(datanames{imonkey});    
    keepNeurons = data.SNR > 2;
    goodNeurons = find(keepNeurons);
    
    events =  data.EVENTS(data.SNR > 2);
    
    counts = computeSpontCounts(events,bininseconds,spacebetweenbins);
    
    scCorr = corrcoef(counts');
    
    scCorrMean = mean(mean(scCorr));
    
    group = zeros(length(goodNeurons));
    
    k = 1;
    
    for ineuron1 = 1: length(goodNeurons)      
        for ineuron2 = ineuron1 + 1: length(goodNeurons)
            
            if(scCorr(ineuron1, ineuron2) > scCorrMean)
                
                group(k, [length(find(group(k, :)))+1:length(find(group(k, :)))+1])= [ineuron2];
            
            end
                      
        end
        
        k = k + 1;
    
    end   
    
    preferred = zeros(1, length(goodNeurons));
    
    im = 1;
    k1 = 1;
    while(im < length(goodNeurons) + 1)
     
        if(preferred(im) == 0)
            
            thisrow = group(im, :);

            for i = 1: length(find(thisrow))

                neuron = thisrow(i);

                [r c] = find(group == neuron);

                preferred(r) = k1;
            end
            
            k1 = k1 + 1
            im = im + 1;
            
        else
            im = im + 1;
        end
        
    end
    
    preferred = preferred;
    max(preferred)
    
    map = data.MAP;
    channel = data.CHANNELS;
    
    for ineuron = 1: length(goodNeurons)
    
        n = goodNeurons(ineuron);
        ch = channel(n, 1);
        [row col] = find(map == ch);
        pinwheel(row, col) = preferred(ineuron);
        
    end
    
    subplot(2, 3, imonkey);
    imagesc(pinwheel);
    colorbar;
    title(['Monkey', num2str(imonkey)], 'interpreter', 'latex');
end