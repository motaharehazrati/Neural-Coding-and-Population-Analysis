clear; clc; close all;

filenames{1} = './spikes_gratings/data_monkey1_gratings.mat';
filenames{2} = './spikes_gratings/data_monkey2_gratings.mat';
filenames{3} = './spikes_gratings/data_monkey3_gratings.mat';

monkeys = {'monkey1', 'monkey2', 'monkey3'};
gratings = {'000', '030', '060', '090', '120', '150', '180', '210','240', '270', '300', '330'};


 
imonkey = 1;

neurons = zeros(3, 112, 12);

for imonkey = 1: length(monkeys)
    load(filenames{imonkey});
    data{imonkey} = data;
    for ineuron = 1: length(data{1, imonkey}.SNR)

        event = data{1, imonkey}.EVENTS;
        eventNeuron = event(ineuron, :, :);

        for igrat = 1: size(data{1, imonkey}.EVENTS, 2)

            eventNeuronGrat = eventNeuron(:, igrat, :);
            eventNeuronGrat = reshape(eventNeuronGrat, [1 200]);
            psth(ineuron, igrat, [1: length(MyPSTH(eventNeuronGrat))]) = ...
                MyPSTH(eventNeuronGrat);

        end    
    end

    neurons(imonkey, [1: length(mean(psth, 3))], :) = mean(psth, 3);   %averaging across time
end

    [maxval preferredGrat] = max(permute(neurons, [3 2 1]));

for imonkey = 1: length(monkeys)
    
    map = data{1, imonkey}.MAP;
    channels = data{1, imonkey}.CHANNELS;

    for ix = 1: size(map, 1)
        for iy = 1: size(map, 2)

            ch = map(ix, iy);
            n = find(channels(:, 1) == ch);
            pinwheel(ix, iy) = mode(preferredGrat(:, n, imonkey));

        end
    end

    figure;
    imagesc(pinwheel);
    colorbar;
    title(monkeys{imonkey}, 'interpreter', 'latex');
    
end


