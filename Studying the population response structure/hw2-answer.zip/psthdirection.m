clear all;
close all;
t = linspace(-1.2,2,60);
load UnitsData
unit_number = 1;
ucti=[];
h=[];
 ut = Unit(unit_number).Trls; %trials for each unit
 for i=1:3:6
     uct =Unit(unit_number).Cnd(i).TrialIdx;
     for j=1:1:length(uct)
         trl_num =uct(j);
         uti=ut(trl_num);
         uti = uti{1};
         h(j,:)=hist(uti,60);
         
     end
       h=mean(h);
      
         
%          
         p=smooth(h);
          plot(t,p/0.053,'LineWidth',3);
          hold on
%     avg=mean(h);
     
 end
% hold on 
% plot(t,avg);
xlim([-1.2,2])
% % legend("Cnd = 1","Cnd = 2","Cnd = 3","Cnd = 4","Cnd = 5","Cnd = 6") 
% legend("reward=3","reward=6","reward=9")
xlabel('time')
ylabel('firing rate')
% % title('PSTH for 6 conditions')
% title('PSTH for diffrent rewards')
legend("dir=1","dir=-1")