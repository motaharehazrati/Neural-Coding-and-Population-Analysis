clear all;
close all;
n = 481;
t = linspace(-1.2,2,60);
un = [];
y=[];
pValVec = [];
reward = [3 3 6 6 9 9];
load UnitsData
for i = 1:1:481
    ut = Unit(i).Trls;    
    for j = 1:length(ut)  
        mat=cell2mat(ut);
        h(j,:) = hist(mat,60);
    end
    units_psth = h/(0.053);
    for l = 1:1:6
        y(Unit(i).Cnd(l).TrialIdx) = reward(l);
    end
    y=y';

    mdl = fitglm(units_psth,y);
    pVal = coefTest(mdl);
    un = [un i];
    pValVec = [pValVec pVal];
    
 end
