clear all;
close all;
clc
fr_vect = 30: 10: 1000;
tSim = [2, 2, 10];
nTrials1 = 1000;
k_vect= [1, 4, 51];
t0 = 1; %msec %refractory period
for j = 1: length(k_vect)
    k = k_vect(j);
    for i = 1: 1: length(fr_vect)
         fr = fr_vect(i);
        [spikeMat, tVec] = poissonSpikeGen(fr, tSim(j), nTrials1);
        
        nTrials = size(spikeMat, 1);
        
        kspikeMat = zeros(nTrials, size(spikeMat, 2));
        for m = 1: 1: nTrials
            v = find(spikeMat(m, :));
            v = v([1: k: end]);
            kspikeMat(m, [v]) = 1; 
        end
        
        ISI = zeros(nTrials, 150);
        for n = 1: 1: nTrials
            ISI(n, [1: 1: length(diff(find(kspikeMat(n, :))))]) = ...
            diff(find(kspikeMat(n, :)));
        end
        ISI = reshape(ISI, [], 1);
        ISI = ISI(find(ISI));
        
        ISI = ISI + t0;
        CV(j, i) = std(ISI) / mean(ISI);
        mean_ISI(j, i) = mean(ISI);
    end
end


theoreticalCV = 1 ./ sqrt(k_vect);
figure;
plot(1000 ./ fr_vect, ones(1, length(mean_ISI))*theoreticalCV(1));
hold all;
plot(1000 ./ fr_vect, ones(1, length(mean_ISI))*theoreticalCV(2));
plot(1000 ./ fr_vect, ones(1, length(mean_ISI))*theoreticalCV(3));
plot(1000 ./ fr_vect, CV(1, :));
plot(1000 ./ fr_vect, CV(2, :));
plot(1000 ./ fr_vect, CV(3, :));
ylim([0 1.2]);

