clear all;
close all;
clc
fr = 100;
tSim = 1;
nTrials = 10;
[spikeMat, tVec] = poissonSpikeGen(fr, tSim, nTrials);
figure
plotRaster(spikeMat,1000* tVec);
p.FaceColor = [.5 0 .5];
% spikeCount = sum(spikeMat, 2);
% figure
% hist(spikeCount,100);
% hold on
% x = 70: 1: 130;
% y = 150*poisspdf(x, 100);
% plot(x, y, 'Linewidth', 3, 'color', 'r');
% ISI = zeros(nTrials, 150);
% for i = 1: 1: nTrials
%         ISI(i, [1: 1: length(diff(find(spikeMat(i, :))))]) = ...
%         diff(find(spikeMat(i, :)));
% end
% ISI = reshape(ISI, [], 1);
% ISI = ISI(find(ISI));
% figure
% hist(ISI,100)
% hold on
% x = 0: 1: 60;
% y = 1000* exp(-fr * x / 1000);
% plot(x, y, 'linewidth', 1, 'color', 'r');

