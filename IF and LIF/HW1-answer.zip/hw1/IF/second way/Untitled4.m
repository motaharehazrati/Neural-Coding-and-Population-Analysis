clear all;
close all;
clc
fr = 100;
tSim = 1;
nTrials = 100;
k=4;
[spikeMat, tVec] = poissonSpikeGen(fr, tSim, nTrials);
kspikeMat = zeros(nTrials, size(spikeMat, 2));
for i = 1: 1: nTrials
        v = find(spikeMat(i, :));
        v = v([1: k: end]);
        kspikeMat(i, [v]) = 1; 
end
spikeCount = sum(kspikeMat, 2);
figure
hist(spikeCount, 10);
hold on
x = 10: 1: 40;
y = 150*poisspdf(x, 100/k);
plot(x, y, 'Linewidth', 3, 'color', 'r');

ISI = zeros(nTrials, 150);
for i = 1: 1: nTrials
        ISI(i, [1: 1: length(diff(find(kspikeMat(i, :))))]) = ...
        diff(find(kspikeMat(i, :)));
end
ISI = reshape(ISI, [], 1);
ISI = ISI(find(ISI));
figure
hist(ISI,100)
hold on
x = 0: 1: 60;
y = 100* exp(-fr * x / 1000);
plot(x, y, 'linewidth', 1, 'color', 'r');