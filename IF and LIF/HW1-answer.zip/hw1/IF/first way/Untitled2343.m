clear all;
close all;
clc
t=0;
for i=1:100
    spike(i)=exprnd(0.01)
    t(i+1)=t(i)+spike(i)
    y(i)=1;
end

% for i=1:length(t)
%     plot([t(i) t(i)],[0 1], 'b');
%     hold on;
% end
stem(t(1,2:end),y,'b')
figure
hist(spike,100,'exponential')



    
