clear all;
close all;
clc
t=0;
n=10;
t1=0;
t0=0.001;
for i=1:100
    spike(i)=exprnd(0.01+t0);
    t(i+1)=t(i)+spike(i);
    y(i)=1;
    r=-log(spike(i));
    spike1(i)=spike(i)*(r^(n-1));
    t1(i+1)=t1(i)+spike1(i);
    y1(i)=1;
    cv(i)=std(spike)/mean(spike);
    tbar(i)=mean(spike);
    if r<0
        disp('*');
    end 
end
figure
stem(t(1,2:end),y,'b')
figure
hist(spike,100,'exponential')
figure
stem(t1(1,2:end),y1,'b')
figure
hist(spike1,100,'exponential')
figure
plot(tbar,cv)



    
