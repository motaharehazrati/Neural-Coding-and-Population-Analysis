clc
clear
R=100;
dt=0.001;

t=[0];
ISI=[];

i=1;
while t(i)<1
    isi = exprnd(1/R);
    ISI=[ISI isi];
    t(i+1) = t(i) + isi;
    i=i+1;
end


k =2;
t_copy = t;
new_t=[];
ISI_copy = ISI;
new_ISI = [];
while numel(t_copy)>k+1
    for counter = 1:k+1
        if counter ==  k+1
            new_t= [new_t t_copy(counter)];
            t_copy = t_copy(1,counter+1:end);
            
            new_ISI= [new_ISI ISI_copy(counter)];
            ISI_copy = ISI_copy(1,counter+1:end);
        end
    end
   
end


figure;
subplot(2,2,1)
stem(new_t,ones(1,numel(new_t)))   
subplot(2,2,2)
histfit(new_ISI,20,'gamma')

subplot(2,2,3)
stem(t,ones(1,numel(t)))
subplot(2,2,4)
histfit(ISI,20,'exponential')
% hold on
% T=0:dt;0.1;
% plot (T,r*exp(-r.*T));