clear; clc; close all;
vr = 0;
Tm = 13; %msec
I = 20; %mv
v(1) = vr;
dt = 0.05; %ms
vth = 15; %mv
time = 0: dt: 100; %msec
s = 0; %spike count
for i = 1: 1: length(time)-1
    dvdt(i) = (1/Tm)*(-v(i) + I);
    v(i+1) = v(i) + dt * dvdt(i);
    if (v(i+1) > vth)
        v(i+1) = 0;
        s = s + 1;
    end
end
rate = s/0.1;
figure;
plot(time, v);
title('Membrane Potential','interpreter', 'latex');
xlabel('time(ms)', 'interpreter', 'latex');
ylabel('Membrane Voltage(mv)','interpreter', 'latex');
ylim([0 17]);