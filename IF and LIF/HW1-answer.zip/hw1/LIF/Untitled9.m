clear; clc; close all;
tSim = 5;
nTrials = 1;
fr = 100;
p_vec = [1: 1: 100];
vr = 0;
Tm_vec = [0.1: 4: 20]; %msec
vth = 15;
for j = 1: 1: length(Tm_vec)
    Tm = Tm_vec(j);
    for i = 1: 1: length(p_vec)
        p = p_vec(i);
        for k = 1: 1: 800  %100 input neurons
            I0 = 10;
            tPeak = 1.5; %msec
            [ISpikes, tVec] = poissonSpikeGen(fr, tSim, nTrials);
            ISpikes = double(ISpikes);
             r = rand(1);
             if(r < p/100)
                ISpikes = ISpikes * (-1);
             end
            ISpikes= reshape(ISpikes, [], 1);
            Is = tVec * 1000 .* exp(-tVec ./ tPeak * 1000);   
             I(:,k) = I0 * conv(ISpikes, Is, 'same');
           
        end
    end
        I = sum(I, 2);
        s = 0;
        vSpike = zeros(1, length(I));
        v(1) = vr;
        dt = 0.05;
        for i = 1: 1: length(I)-1
       dvdt(i) = (1/Tm)*(-v(i) + I(i));
       v(i+1) = v(i) + dt * dvdt(i);
       if (v(i+1) > vth)
           v(i+1) = 0;
           s = s + 1;
           vSpike(i+1) = 1;
       end
        nTrials = size(vSpike, 1);
    ISI = zeros(nTrials, 150);
    for i = 1: 1: nTrials
        ISI(i, [1: 1: length(diff(find(vSpike(i, :))))]) = ...
            diff(find(vSpike(i, :)));
    end
    ISI = reshape(ISI, [], 1);
    ISI = ISI(find(ISI));
        cv(j, i) = std(ISI)/mean(ISI);
     end
end
close all;
hold all;
plot(p_vec, cv(2, :));
plot(p_vec, cv(3, :));
plot(p_vec, cv(4, :));
plot(p_vec, cv(5, :));
xlim([20 60])
ylim([0 1])
legend('Tm = 4.1%', 'Tm = 8.1%', 'Tm = 12.1%', 'Tm = 16.1%');