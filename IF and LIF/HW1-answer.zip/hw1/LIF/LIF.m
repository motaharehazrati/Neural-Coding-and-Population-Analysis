clear all; 
clc; 
close all;

Tm = 13; 
% I = 20; 
vr = 0; 
vth = 15; 
v(1) = vr;
% dt = 0.05; 
% time = 0: dt: 100;
spike = 0; 
% 
% 
% for i = 1: 1: length(time)-1
%     vprime(i) = (1/Tm)*(-v(i) + I);
%     v(i+1) = v(i) + dt * vprime(i); %finding v
%     if (v(i+1) > vth)
%         v(i+1) = 0;
%         spike = spike + 1;
%     end
% end
% 
% rate = spike*10;
% figure;
% plot(time, v);
% ylim([0 17]);


% considering i
% 
fr=200;
tSim = 1; %s
nTrials = 10;
I0 = 100;
tPeak = 1.5; %msec
[ISpikes, tVec] = poissonSpikeGen(fr, tSim, nTrials);
ISpikes= reshape(ISpikes, [], 1);
Is = tVec * 1000 .* exp(-tVec ./ tPeak * 1000);   
I = I0 * conv(ISpikes, Is, 'same');
figure
plot(I);
xlim([0 300]);
s = 0;
vSpike = zeros(1, length(I));
v(1) = vr;
dt = 0.05;
for i = 1: 1: length(I)-1
    vSpike = zeros(1, length(I));
    vprime(i) = (1/Tm)*(-v(i) + I(i));
    v(i+1) = v(i) + dt * vprime(i); %finding v
    if (v(i+1) > vth)
        v(i+1) = 0;
        spike = spike + 1;
        vSpike(i+1) = 1;
    end
end
figure
plot(v);
xlim([0 300]);


